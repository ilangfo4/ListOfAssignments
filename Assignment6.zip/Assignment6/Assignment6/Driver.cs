﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
namespace Assignment6
{
    class Driver
    {
        static void Main(string[] args)
        {
           
            WordJumble game = new WordJumble();
           
            game.playGame(game);
            Console.WriteLine("Type NEW for a new game, or CONTINUE to restore an old game?");
            string user = Console.ReadLine();
            if (user == "NEW")
            {
                game.playGame(game);
            }
            else if (user == "CONTINUE")
            {
                game.playGame(game.restoreGame());
            }
        }
    }
}