﻿using System;
using System.Collections.Generic;
using System.Threading;
namespace Lab14
{
	public class Cow
	{
		private static Node head;
		public static void list(Milk m)
		{
			Node moreMilk = new Node(m);
			if(head == null)
			{
				head = moreMilk;
			}
			else
			{
				Node n = head;
                while (n.getNext() != null)
                {
                    n = n.getNext();
                }
				n.setNext(moreMilk);
            }
			
			
		}
		
		public void run()
		{

            try
            { 
                Random rnd = new Random();
                while (true)
                {
                    Milk newMilk = new Milk();
                    int time = rnd.Next(5000, 10000);
                    Thread.Sleep(time);
					list(newMilk);
                }
            }
			catch(ThreadInterruptedException e)
			{
				Console.WriteLine(e.Message);
			}
			
		}

        public bool haveMilk()
        {
			if (head == null)
				return true;
			else
				return false;
        }

		public Milk takeMilk()
		{
            if (head == null)
                return null;
            else
            {
                Node n = head;
                head = head.getNext();
                return n.getMilk();
            }
        }

		public int countMilk()
		{
            int count = 0;
            if (head == null)
                return 0;
            else
            {
                Node n = head;
                while (n != null)
                {
                    n = n.getNext();
                    count++;
                }
                return count;
            }
        }
    }

	
}

