﻿using System;
using System.Threading;
namespace Lab14
{
	public class Driver
	{
		static void Main(string[] args)
		{
			Thread[] arr = new Thread[4];
			Cow cow = new Cow();
			CreamFactory creamFactory = new CreamFactory();
			ButterFactory butterFactory = new ButterFactory();
			for(int i = 0; i < arr.Length; i++)
			{
				arr[i] = new Thread(new ThreadStart(cow.run));
				arr[i].Start();
            }

			Thread t1 = new Thread(butterFactory.run);
			Thread t2 = new Thread(creamFactory.run);
			t1.Start();
			t2.Start();
			//The program will stop when thread array which calls the cow's main method becomes dead, therefore there would be no more milk to collect from.
		}
	}
}

