﻿using System;
namespace Lab14
{
	public class Node
	{
		private Milk milk;
		private Node next;

		public Node(Milk m)
		{
			milk = m;
			next = null;
		}

		public Milk getMilk()
		{
			return milk;
		}

		public void setMilk(Milk m)
		{
			milk = m;
		}

		public Node getNext()
		{
			return next;
		}

		public void setNext(Node n)
		{
			next = n;
		}
	}
}

