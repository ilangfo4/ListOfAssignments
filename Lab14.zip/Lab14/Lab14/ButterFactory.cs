﻿using System;
using System.Threading;
namespace Lab14
{
	public class ButterFactory
	{
		public void run()
		{
			int count = 0;
			try
			{
                while (true)
                {
                    Cow cow = new Cow();
                    Milk milk = new Milk();
                    if (cow.haveMilk())
                    {
                        
                            cow.takeMilk();
                            count++;
                            Console.WriteLine("Butter Factory got milk from a cow");
                            Console.WriteLine("Now Butter Factory has " + count + " milk");

                            if (count % 4 == 0)
                            {
                                Console.WriteLine("I made butter");
                                count -= 4;
                                Thread.Sleep(1000);
                            }
                        

                    }
                }
            }
			catch(ThreadInterruptedException e)
			{
				Console.WriteLine("Error in ButterFactory. " + e.Message);
			}
		}
	}
}

