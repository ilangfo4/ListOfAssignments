﻿using System;
namespace Lab14
{
	public class LinkedList
	{
		private Node head;

		public LinkedList()
		{
			head = null;
		}

		public void add(Milk m)
		{
			Node temp = new Node(m);
			if(head == null)
			{
				head = temp;
			}
			else
			{
				Node n = head;
				while(n.getNext() != null)
				{
					n = n.getNext();
				}
				n.setNext(temp);
			}
		}

		public Milk getNext()
		{
			if (head == null)
				return null;
			else
			{
				Node n = head;
				head = head.getNext();
				return n.getMilk();
			}
		}

		public int countItems()
		{
			int count = 0;
			if (head == null)
				return 0;
			else
			{
				Node n = head;
				while(n != null)
				{
					n = n.getNext();
					count++;
				}
				return count;
			}
		}

		public bool isEmpty()
		{
			if (head == null)
				return true;
			else
				return false;
		}
	}
}

