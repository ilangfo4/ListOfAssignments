﻿using System;
namespace Lab14
{
    public class Milk
    {

    }
}