﻿using System;
using System.Collections.Generic;
namespace Lab13
{
    class Driver
    {
        static void Main(string[] agrs)
        {
            BlueRayCollection bdc = new BlueRayCollection();
            int answer;
            do
            {
                Console.WriteLine("0. Quit");
                Console.WriteLine("1. Add BlueRay to collection");
                Console.WriteLine("2. See collection");
                answer = Convert.ToInt32(Console.ReadLine());
                switch (answer)
                {
                    case 0:
                        break;
                    case 1:
                        Console.WriteLine("What is the title?");
                        string title = Console.ReadLine();
                        Console.WriteLine("Who is the director?");
                        string director = Console.ReadLine();
                        Console.WriteLine("What is the year of the release");
                        int yearOfRelease = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("What is the cost?");
                        double cost = double.Parse(Console.ReadLine());
                        BlueRayDisk brd = new BlueRayDisk(title, director, yearOfRelease, cost);
                        bdc.add(brd);
                        break;
                    case 2:
                        bdc.show_all();
                        break;
                }
            } while(answer != 0);
        }
    }
}