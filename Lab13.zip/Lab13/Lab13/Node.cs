﻿using System;
namespace Lab13
{
    public class Node
    {
        internal BlueRayDisk data;
        internal Node next;
        public Node(BlueRayDisk disk)
        {
            data = disk;
            next = null;
        }
    }
}

