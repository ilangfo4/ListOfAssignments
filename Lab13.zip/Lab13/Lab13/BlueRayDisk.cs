﻿using System;
namespace Lab13
{
	public class BlueRayDisk
	{
		public string title;
		public string director;
		public int yearOfRelease;
		public double cost;

		public BlueRayDisk(string title, string director, int yearOfRelease, double cost)
		{
			this.title = title;
			this.director = director;
			this.yearOfRelease = yearOfRelease;
			this.cost = cost;

		}

		
	}
}

