﻿using System;
namespace Lab13
{
	public class BlueRayCollection
	{
		private Node head = null;

		public void add(BlueRayDisk disk)
		{
			Node newDisk = new Node(disk);
			if(head == null)
			{
				head = newDisk;
				return;
			}
			newDisk.next = null;
			Node current = head;
			while(current.next != null)
			{
				current = current.next;
			}
			current.next = newDisk;
			return;
		}

		public void show_all()
		{
			Node newNode = head;
			while(newNode != null)
			{
				Console.WriteLine(ToString(newNode));
				newNode = newNode.next;
			}
		}

		public string ToString(Node node)
		{
			return "$" + node.data.cost + " " + node.data.yearOfRelease + " " + node.data.title + "," + node.data.director;
		}
	}
}

