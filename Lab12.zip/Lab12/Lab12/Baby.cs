﻿using System;
using System.Threading;
namespace Lab12
{
    class Baby
    {
        private int time;
        private string name;

        public Baby(string name)
        {
            this.name = name;
            Random rnd = new Random();
            time = rnd.Next(5000);  
        }

        public void run()
        {
            try
            {
                Console.WriteLine("My name is " + name + " im going to sleep for " + time + "ms");
                Thread.Sleep(time);
                Console.WriteLine("My name is " + name + " ,I am awake, feed me!!!");
            }
            catch(ThreadInterruptedException e)
            {
                Console.WriteLine(e.Message);
            }
  
        }
    }
}