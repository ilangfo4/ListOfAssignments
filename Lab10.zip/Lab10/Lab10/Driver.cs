﻿using System;
using System.IO;
namespace Lab10
{
    public class Driver
    {
        static void Main(string[] args)
        {
            
        }
    }
}

