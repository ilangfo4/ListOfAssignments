﻿using System;
using System.Text;
using System.IO;
namespace Lab10
{
    public class InvalidFile : Exception
    {
        public InvalidFile(string msg) : base(msg) { }
    }


}