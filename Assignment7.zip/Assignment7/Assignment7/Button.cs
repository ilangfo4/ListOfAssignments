﻿namespace Project10
{
    internal class Button
    {
    }
}